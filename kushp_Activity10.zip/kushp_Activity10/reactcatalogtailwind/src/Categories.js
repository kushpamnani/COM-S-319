export const Categories = [
    "electronics",
    "jewelery"
    ,
    "men's clothing",
    "women's clothing"
    ]